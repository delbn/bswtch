
const UiColors = {
    primary: "#01bb88",
    secondary: "#33383c",
    accent: "#2c2f32",
    white: "white",
};

export default UiColors;
